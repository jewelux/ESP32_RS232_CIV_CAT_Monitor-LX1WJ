# Usage Guide

## ICOM Mode

PROTO ICOM
TXFMT HEX

Example:
FE FE 94 E0 03 FD

## ELECRAFT Mode

PROTO ELE
TXFMT ASCII

Example:
FA;
MD2;
TX;
RX;

Commands are sent only after pressing ENTER.
